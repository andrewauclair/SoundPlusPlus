var classspp___processing_plug_in =
[
    [ "spp_ProcessingPlugIn", "d5/d6c/classspp___processing_plug_in.html#a9ce1070cfb124c816f345d4e8621aab3", null ],
    [ "~spp_ProcessingPlugIn", "d5/d6c/classspp___processing_plug_in.html#aeca8f4edcdd6641093f59f6755ffd104", null ],
    [ "IsActive", "d5/d6c/classspp___processing_plug_in.html#abfa5fb68962649665ba16c9babeccde5", null ],
    [ "ProcessSamples", "d5/d6c/classspp___processing_plug_in.html#ad2027b5a2bbc5824e0e6f236c2992f4b", null ],
    [ "SetIsActive", "d5/d6c/classspp___processing_plug_in.html#a8d2de5df7c5dbd75ec3d7b396323c013", null ]
];