var hierarchy =
[
    [ "spp_3D_Audio_Data", "d9/d1a/structspp__3_d___audio___data.html", null ],
    [ "spp_3DAudioProperties", "db/de3/structspp__3_d_audio_properties.html", null ],
    [ "spp_3DSpatialInformation", "df/db2/structspp__3_d_spatial_information.html", null ],
    [ "spp_AudioListener", "d2/dd7/classspp___audio_listener.html", null ],
    [ "spp_AudioListenerProperties", "d1/dc2/structspp___audio_listener_properties.html", null ],
    [ "spp_AudioPlaybackProperties", "d9/d4e/structspp___audio_playback_properties.html", null ],
    [ "spp_AudioRecorder", "d0/d92/classspp___audio_recorder.html", null ],
    [ "spp_AudioSource", "de/dc3/classspp___audio_source.html", null ],
    [ "spp_Microphone", "d1/d33/classspp___microphone.html", null ],
    [ "spp_OGG_Data", "d3/d72/structspp___o_g_g___data.html", null ],
    [ "spp_ProcessingPlugIn", "d5/d6c/classspp___processing_plug_in.html", null ],
    [ "spp_SignalProcessor", "d3/da9/classspp___signal_processor.html", [
      [ "spp_AudioManager", "d1/d0c/classspp___audio_manager.html", null ],
      [ "spp_StreamingSource", "d7/df9/classspp___streaming_source.html", null ]
    ] ],
    [ "spp_WAV_Data", "de/d98/structspp___w_a_v___data.html", null ]
];