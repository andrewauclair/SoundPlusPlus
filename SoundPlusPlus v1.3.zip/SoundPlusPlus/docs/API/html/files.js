var files =
[
    [ "Library and Test/SoundPlusPlus/spp_AudioListener.cpp", "de/d26/spp___audio_listener_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_AudioListener.h", "d4/d49/spp___audio_listener_8h.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_AudioManager.cpp", "de/d4f/spp___audio_manager_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_AudioManager.h", "dc/d84/spp___audio_manager_8h.html", "dc/d84/spp___audio_manager_8h" ],
    [ "Library and Test/SoundPlusPlus/spp_AudioRecorder.cpp", "d5/da2/spp___audio_recorder_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_AudioRecorder.h", "d7/d75/spp___audio_recorder_8h.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_AudioSource.cpp", "d6/da4/spp___audio_source_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_AudioSource.h", "d2/d33/spp___audio_source_8h.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_Microphone.cpp", "db/d71/spp___microphone_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_Microphone.h", "db/d7f/spp___microphone_8h.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_ProcessingPlugIn.cpp", "d3/dd2/spp___processing_plug_in_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_ProcessingPlugIn.h", "d4/d1e/spp___processing_plug_in_8h.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_SignalProcessor.cpp", "db/d6e/spp___signal_processor_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_SignalProcessor.h", "d7/d26/spp___signal_processor_8h.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_StreamingSource.cpp", "d7/dee/spp___streaming_source_8cpp.html", null ],
    [ "Library and Test/SoundPlusPlus/spp_StreamingSource.h", "d9/dc9/spp___streaming_source_8h.html", null ]
];