var structspp__3_d_audio_properties =
[
    [ "HalfVolumeDistance", "db/de3/structspp__3_d_audio_properties.html#ad4b6a50a599e862ee686f80b0c13d9da", null ],
    [ "MaxAudibleDistance", "db/de3/structspp__3_d_audio_properties.html#a63e23cc63978e322331c887bbf72ff32", null ],
    [ "SoundRolloffFactor", "db/de3/structspp__3_d_audio_properties.html#a1978acace2dd4dbd8b6729ddd5b235bc", null ]
];