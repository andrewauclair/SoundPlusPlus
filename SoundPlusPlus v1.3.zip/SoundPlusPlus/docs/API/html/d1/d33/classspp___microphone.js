var classspp___microphone =
[
    [ "spp_Microphone", "d1/d33/classspp___microphone.html#a30e48d69beb1929a0907ce4ac59606ff", null ],
    [ "~spp_Microphone", "d1/d33/classspp___microphone.html#a911864027befc9ebd554a3bbc0ca8f69", null ],
    [ "Set3DAudioProperties", "d1/d33/classspp___microphone.html#aecfe57d69801aa2cb1991a8fe75862c4", null ],
    [ "Set3DSpatialInformation", "d1/d33/classspp___microphone.html#a71ba843ee0364b959000006087e64779", null ],
    [ "SetAudioPlaybackProperties", "d1/d33/classspp___microphone.html#a5720e9a27a568d50d42c7835eafeed50", null ],
    [ "SetSamplesCapturedBeforeRead", "d1/d33/classspp___microphone.html#a106a2df577672c6ea06b2b51c013d3f7", null ],
    [ "Start", "d1/d33/classspp___microphone.html#a026593b252e4f440d03517e082ebad8f", null ],
    [ "Stop", "d1/d33/classspp___microphone.html#a87ba453b4a70919dee0e72361b02a202", null ],
    [ "Update", "d1/d33/classspp___microphone.html#aae35ec1a2290db3bf9a85484e8e69898", null ]
];