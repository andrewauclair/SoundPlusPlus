var searchData=
[
  ['_7espp_5faudiomanager',['~spp_AudioManager',['../d1/d0c/classspp___audio_manager.html#a10a2cfc2a682f806f4d2dc3f16950cf9',1,'spp_AudioManager']]],
  ['_7espp_5faudiorecorder',['~spp_AudioRecorder',['../d0/d92/classspp___audio_recorder.html#ae6774a139a2341651c46d015ebb29eb2',1,'spp_AudioRecorder']]],
  ['_7espp_5faudiosource',['~spp_AudioSource',['../de/dc3/classspp___audio_source.html#a503c84d62fa786b61f33083b8262580a',1,'spp_AudioSource']]],
  ['_7espp_5fmicrophone',['~spp_Microphone',['../d1/d33/classspp___microphone.html#a911864027befc9ebd554a3bbc0ca8f69',1,'spp_Microphone']]],
  ['_7espp_5fprocessingplugin',['~spp_ProcessingPlugIn',['../d5/d6c/classspp___processing_plug_in.html#aeca8f4edcdd6641093f59f6755ffd104',1,'spp_ProcessingPlugIn']]],
  ['_7espp_5fsignalprocessor',['~spp_SignalProcessor',['../d3/da9/classspp___signal_processor.html#ab19f035bb8fcde57bc2b872e00ed7813',1,'spp_SignalProcessor']]],
  ['_7espp_5fstreamingsource',['~spp_StreamingSource',['../d7/df9/classspp___streaming_source.html#a1c23729ed38085758f64254267b33428',1,'spp_StreamingSource']]]
];
