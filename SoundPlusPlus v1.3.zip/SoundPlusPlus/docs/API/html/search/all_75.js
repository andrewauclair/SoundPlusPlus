var searchData=
[
  ['unloadallsounds',['UnloadAllSounds',['../d1/d0c/classspp___audio_manager.html#a4a35e06e44b3c097aa14b759793517fd',1,'spp_AudioManager']]],
  ['unloadsound',['UnloadSound',['../d1/d0c/classspp___audio_manager.html#a5a4b93914cd8f70510afc467b9176268',1,'spp_AudioManager']]],
  ['update',['Update',['../d0/d92/classspp___audio_recorder.html#a9e89b17713c69d14b75e525ed402afea',1,'spp_AudioRecorder::Update()'],['../d1/d33/classspp___microphone.html#aae35ec1a2290db3bf9a85484e8e69898',1,'spp_Microphone::Update()'],['../d7/df9/classspp___streaming_source.html#a2e44780abc5e7e4a93dbc466357e212f',1,'spp_StreamingSource::Update()']]],
  ['upvector',['UpVector',['../d1/dc2/structspp___audio_listener_properties.html#ac9ad9a4df08b6077d47e08bf766c8c12',1,'spp_AudioListenerProperties']]]
];
