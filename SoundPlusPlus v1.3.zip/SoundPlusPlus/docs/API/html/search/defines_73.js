var searchData=
[
  ['spp_5fbuffers_5fto_5fqueue',['SPP_BUFFERS_TO_QUEUE',['../dc/d84/spp___audio_manager_8h.html#a527172339b23f69c80476111ce44ebdf',1,'spp_AudioManager.h']]],
  ['spp_5fmax_5frecording_5fsample_5fbatch_5fsize',['SPP_MAX_RECORDING_SAMPLE_BATCH_SIZE',['../dc/d84/spp___audio_manager_8h.html#a621b6b0b1a3d3f3630c688e8aae22361',1,'spp_AudioManager.h']]],
  ['spp_5fogg_5fsize_5fto_5fread',['SPP_OGG_SIZE_TO_READ',['../dc/d84/spp___audio_manager_8h.html#affc515455855eec37d97dc79fcf5ec60',1,'spp_AudioManager.h']]],
  ['spp_5frecording_5ffrequency',['SPP_RECORDING_FREQUENCY',['../dc/d84/spp___audio_manager_8h.html#a43f938ca6a048b535e79df160952e883',1,'spp_AudioManager.h']]]
];
