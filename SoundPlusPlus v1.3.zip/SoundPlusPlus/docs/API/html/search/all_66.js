var searchData=
[
  ['file',['File',['../d3/d72/structspp___o_g_g___data.html#aef1491420692fa2fb055f5e7e9964559',1,'spp_OGG_Data']]],
  ['format',['format',['../d3/d72/structspp___o_g_g___data.html#a720f635874d1224c39d1a6131add1daf',1,'spp_OGG_Data']]],
  ['formattype',['formatType',['../de/d98/structspp___w_a_v___data.html#abbdb6285c6330091430c4ec27b201d60',1,'spp_WAV_Data']]],
  ['freq',['freq',['../d3/d72/structspp___o_g_g___data.html#aa77f18dce029b6711f541a21650c027b',1,'spp_OGG_Data']]]
];
