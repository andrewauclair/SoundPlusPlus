var searchData=
[
  ['type',['type',['../de/d98/structspp___w_a_v___data.html#ad9089674fdd38ecce4b0ac36151bf34a',1,'spp_WAV_Data']]]
];
