var searchData=
[
  ['maxaudibledistance',['MaxAudibleDistance',['../db/de3/structspp__3_d_audio_properties.html#a63e23cc63978e322331c887bbf72ff32',1,'spp_3DAudioProperties']]],
  ['maximumvolume',['MaximumVolume',['../d9/d4e/structspp___audio_playback_properties.html#a5d6a6cf38561b75fe65afe68af43542f',1,'spp_AudioPlaybackProperties']]],
  ['minimumvolume',['MinimumVolume',['../d9/d4e/structspp___audio_playback_properties.html#ac189c8e62d4c3fe87e87ad70543eeea6',1,'spp_AudioPlaybackProperties']]]
];
