var searchData=
[
  ['channels',['channels',['../de/d98/structspp___w_a_v___data.html#a0598e26692d6fa2bd907457abc158c1c',1,'spp_WAV_Data']]],
  ['chunksize',['chunkSize',['../de/d98/structspp___w_a_v___data.html#a36de30f369903446b1af1fc7afa2bc64',1,'spp_WAV_Data']]]
];
