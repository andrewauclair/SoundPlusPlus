var searchData=
[
  ['getaudiodevices',['GetAudioDevices',['../d1/d0c/classspp___audio_manager.html#a65d6fcfb44c1d4bf70170330812d493b',1,'spp_AudioManager']]],
  ['getlistener',['GetListener',['../d1/d0c/classspp___audio_manager.html#a56cc64143309e87f43885892a42f140c',1,'spp_AudioManager']]],
  ['getrecordingdevices',['GetRecordingDevices',['../d1/d0c/classspp___audio_manager.html#aa46bbd4de2bb245628e78e0892bfb685',1,'spp_AudioManager']]]
];
