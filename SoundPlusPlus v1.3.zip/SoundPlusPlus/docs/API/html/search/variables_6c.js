var searchData=
[
  ['lookatvector',['LookAtVector',['../d1/dc2/structspp___audio_listener_properties.html#ab1ec98abe28070851a0f7cc32f694be9',1,'spp_AudioListenerProperties']]],
  ['looping',['Looping',['../d9/d4e/structspp___audio_playback_properties.html#a3ba15c1b1313e482b627f1746e1c8a00',1,'spp_AudioPlaybackProperties']]]
];
