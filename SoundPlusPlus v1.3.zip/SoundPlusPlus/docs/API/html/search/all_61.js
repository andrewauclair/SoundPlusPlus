var searchData=
[
  ['addprocessingplugin',['AddProcessingPlugIn',['../d3/da9/classspp___signal_processor.html#a544b5f9cfc94d642ebf14a8a92dccf46',1,'spp_SignalProcessor']]],
  ['addsoundtomanager',['AddSoundToManager',['../d0/d92/classspp___audio_recorder.html#ab7645011e86dea743c5e9b069fc230c7',1,'spp_AudioRecorder']]],
  ['assignsound',['AssignSound',['../de/dc3/classspp___audio_source.html#ac9086b1f28a8504e60b3ff25b3266550',1,'spp_AudioSource']]],
  ['averagebytespersecond',['averageBytesPerSecond',['../de/d98/structspp___w_a_v___data.html#a06289289e127ab948b45074aa201c14a',1,'spp_WAV_Data']]]
];
