var searchData=
[
  ['loadoggsound',['LoadOGGSound',['../d1/d0c/classspp___audio_manager.html#afdb9e8fb142b4c73b59baa1822f17caa',1,'spp_AudioManager']]],
  ['loadwavsound',['LoadWAVSound',['../d1/d0c/classspp___audio_manager.html#a4a709709cc06820571f4b7c9855d7a34',1,'spp_AudioManager']]]
];
