var searchData=
[
  ['bitspersample',['bitsPerSample',['../de/d98/structspp___w_a_v___data.html#acdab79451c6c34fa77e8561dac4fd61c',1,'spp_WAV_Data']]],
  ['buffer',['buffer',['../de/d98/structspp___w_a_v___data.html#a3eaded1f09742ccd104995fee4c65a65',1,'spp_WAV_Data']]],
  ['bytespersample',['bytesPerSample',['../de/d98/structspp___w_a_v___data.html#a43217ddb8e4eb078c24089a27e94d9a0',1,'spp_WAV_Data']]]
];
