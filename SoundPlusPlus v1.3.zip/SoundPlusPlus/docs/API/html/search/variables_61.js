var searchData=
[
  ['averagebytespersecond',['averageBytesPerSecond',['../de/d98/structspp___w_a_v___data.html#a06289289e127ab948b45074aa201c14a',1,'spp_WAV_Data']]]
];
