var searchData=
[
  ['datasize',['dataSize',['../de/d98/structspp___w_a_v___data.html#a632d564520f80b117d201c128cef5ae5',1,'spp_WAV_Data::dataSize()'],['../d3/d72/structspp___o_g_g___data.html#a27fc0bcf19c2e35ffdc3c8ee4f6e718b',1,'spp_OGG_Data::dataSize()']]],
  ['direction',['Direction',['../df/db2/structspp__3_d_spatial_information.html#a2c5f6fba43d30ab58857dedf08164b8d',1,'spp_3DSpatialInformation']]]
];
