var searchData=
[
  ['halfvolumedistance',['HalfVolumeDistance',['../db/de3/structspp__3_d_audio_properties.html#ad4b6a50a599e862ee686f80b0c13d9da',1,'spp_3DAudioProperties']]]
];
