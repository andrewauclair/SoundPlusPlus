var searchData=
[
  ['islooping',['isLooping',['../d9/d1a/structspp__3_d___audio___data.html#a32c04f0c57761ea5693b978984c99dee',1,'spp_3D_Audio_Data']]]
];
