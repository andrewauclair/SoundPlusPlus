var searchData=
[
  ['velocity',['Velocity',['../d1/dc2/structspp___audio_listener_properties.html#a18b9f433cdda33f56ec80bea0f598c3e',1,'spp_AudioListenerProperties::Velocity()'],['../df/db2/structspp__3_d_spatial_information.html#a9825299673408ab2720681594584b04f',1,'spp_3DSpatialInformation::Velocity()'],['../d9/d1a/structspp__3_d___audio___data.html#a27e4209abde00e6eaac88ba69dbf5820',1,'spp_3D_Audio_Data::velocity()']]],
  ['volume',['Volume',['../d1/dc2/structspp___audio_listener_properties.html#ab2809bd6d64a68bb05d6bf4fecb3d100',1,'spp_AudioListenerProperties::Volume()'],['../d9/d4e/structspp___audio_playback_properties.html#a3f6d82baafb32140a76eb90f30362114',1,'spp_AudioPlaybackProperties::Volume()'],['../d9/d1a/structspp__3_d___audio___data.html#a72de895580549d7476c81f8ae5c1cd89',1,'spp_3D_Audio_Data::volume()']]]
];
