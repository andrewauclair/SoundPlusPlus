var searchData=
[
  ['pause',['Pause',['../de/dc3/classspp___audio_source.html#a1ec7e2ce3a875d47853f43a36c4196a7',1,'spp_AudioSource::Pause()'],['../de/dc3/classspp___audio_source.html#af1c5ab788d6a9277f5516b8d138acb42',1,'spp_AudioSource::Pause(string tag)'],['../d7/df9/classspp___streaming_source.html#a9f48abdeb60a7764dd1b64d9d660d65a',1,'spp_StreamingSource::Pause()']]],
  ['play',['Play',['../de/dc3/classspp___audio_source.html#a2ab241a80b23ae058e6bec3790d9242d',1,'spp_AudioSource::Play()'],['../de/dc3/classspp___audio_source.html#a2458fac1096b94a2caa63367ceb9b9f6',1,'spp_AudioSource::Play(string tag)'],['../d7/df9/classspp___streaming_source.html#af3216f88130f6c0d91220c72b9fe1117',1,'spp_StreamingSource::Play()']]],
  ['preparestream',['PrepareStream',['../d7/df9/classspp___streaming_source.html#a3eb58cf0f2474e0e5ac6b9660027853f',1,'spp_StreamingSource']]],
  ['processsamples',['ProcessSamples',['../d5/d6c/classspp___processing_plug_in.html#ad2027b5a2bbc5824e0e6f236c2992f4b',1,'spp_ProcessingPlugIn::ProcessSamples()'],['../d3/da9/classspp___signal_processor.html#a1fdb8b4f2922d7f72753adb3f98e9b66',1,'spp_SignalProcessor::ProcessSamples()']]]
];
