var searchData=
[
  ['isactive',['IsActive',['../d5/d6c/classspp___processing_plug_in.html#abfa5fb68962649665ba16c9babeccde5',1,'spp_ProcessingPlugIn']]],
  ['isfinished',['IsFinished',['../d7/df9/classspp___streaming_source.html#a0b9c4bd260c3fcecb97605293026c180',1,'spp_StreamingSource']]],
  ['islooping',['isLooping',['../d9/d1a/structspp__3_d___audio___data.html#a32c04f0c57761ea5693b978984c99dee',1,'spp_3D_Audio_Data']]],
  ['isplaying',['IsPlaying',['../de/dc3/classspp___audio_source.html#a03cafe4d96c78bc021ca1a5f2d4325c7',1,'spp_AudioSource::IsPlaying()'],['../de/dc3/classspp___audio_source.html#aa69c0b1b84000258d10a1ce16bd68736',1,'spp_AudioSource::IsPlaying(string tag)'],['../d7/df9/classspp___streaming_source.html#a2041d4b39b0cf07c2157c5420208c499',1,'spp_StreamingSource::IsPlaying()']]]
];
