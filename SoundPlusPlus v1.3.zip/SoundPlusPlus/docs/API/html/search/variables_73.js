var searchData=
[
  ['samplerate',['sampleRate',['../de/d98/structspp___w_a_v___data.html#a7a04efc3c312e272e4d6fef60c55f45f',1,'spp_WAV_Data']]],
  ['size',['size',['../de/d98/structspp___w_a_v___data.html#af47dd383df6682ffb177b7ae86add804',1,'spp_WAV_Data']]],
  ['soundrollofffactor',['SoundRolloffFactor',['../db/de3/structspp__3_d_audio_properties.html#a1978acace2dd4dbd8b6729ddd5b235bc',1,'spp_3DAudioProperties']]]
];
