var structspp__3_d_spatial_information =
[
    [ "Direction", "df/db2/structspp__3_d_spatial_information.html#a2c5f6fba43d30ab58857dedf08164b8d", null ],
    [ "Position", "df/db2/structspp__3_d_spatial_information.html#ad096f9f27ec3237617e3a8c0a7288f14", null ],
    [ "Velocity", "df/db2/structspp__3_d_spatial_information.html#a9825299673408ab2720681594584b04f", null ]
];