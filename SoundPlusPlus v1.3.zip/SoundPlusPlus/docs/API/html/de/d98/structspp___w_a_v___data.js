var structspp___w_a_v___data =
[
    [ "averageBytesPerSecond", "de/d98/structspp___w_a_v___data.html#a06289289e127ab948b45074aa201c14a", null ],
    [ "bitsPerSample", "de/d98/structspp___w_a_v___data.html#acdab79451c6c34fa77e8561dac4fd61c", null ],
    [ "buffer", "de/d98/structspp___w_a_v___data.html#a3eaded1f09742ccd104995fee4c65a65", null ],
    [ "bytesPerSample", "de/d98/structspp___w_a_v___data.html#a43217ddb8e4eb078c24089a27e94d9a0", null ],
    [ "channels", "de/d98/structspp___w_a_v___data.html#a0598e26692d6fa2bd907457abc158c1c", null ],
    [ "chunkSize", "de/d98/structspp___w_a_v___data.html#a36de30f369903446b1af1fc7afa2bc64", null ],
    [ "dataSize", "de/d98/structspp___w_a_v___data.html#a632d564520f80b117d201c128cef5ae5", null ],
    [ "formatType", "de/d98/structspp___w_a_v___data.html#abbdb6285c6330091430c4ec27b201d60", null ],
    [ "sampleRate", "de/d98/structspp___w_a_v___data.html#a7a04efc3c312e272e4d6fef60c55f45f", null ],
    [ "size", "de/d98/structspp___w_a_v___data.html#af47dd383df6682ffb177b7ae86add804", null ],
    [ "type", "de/d98/structspp___w_a_v___data.html#ad9089674fdd38ecce4b0ac36151bf34a", null ]
];