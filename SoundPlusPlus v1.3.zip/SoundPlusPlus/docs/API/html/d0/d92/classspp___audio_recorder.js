var classspp___audio_recorder =
[
    [ "spp_AudioRecorder", "d0/d92/classspp___audio_recorder.html#a2df815b379a6f22be064b806e09dd4a5", null ],
    [ "~spp_AudioRecorder", "d0/d92/classspp___audio_recorder.html#ae6774a139a2341651c46d015ebb29eb2", null ],
    [ "AddSoundToManager", "d0/d92/classspp___audio_recorder.html#ab7645011e86dea743c5e9b069fc230c7", null ],
    [ "SetSamplesCapturedBeforeRead", "d0/d92/classspp___audio_recorder.html#a066ade8fc675b85cd79a56a1e2ecdda8", null ],
    [ "Start", "d0/d92/classspp___audio_recorder.html#ac3d93dc9bdbc215c0139dbaf12359a8c", null ],
    [ "Stop", "d0/d92/classspp___audio_recorder.html#a1b0562f490d7497433e391d6a4ac0dd7", null ],
    [ "Update", "d0/d92/classspp___audio_recorder.html#a9e89b17713c69d14b75e525ed402afea", null ]
];