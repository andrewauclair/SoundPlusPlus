var spp___audio_manager_8h =
[
    [ "SPP_BUFFERS_TO_QUEUE", "dc/d84/spp___audio_manager_8h.html#a527172339b23f69c80476111ce44ebdf", null ],
    [ "SPP_MAX_RECORDING_SAMPLE_BATCH_SIZE", "dc/d84/spp___audio_manager_8h.html#a621b6b0b1a3d3f3630c688e8aae22361", null ],
    [ "SPP_OGG_SIZE_TO_READ", "dc/d84/spp___audio_manager_8h.html#affc515455855eec37d97dc79fcf5ec60", null ],
    [ "SPP_RECORDING_FREQUENCY", "dc/d84/spp___audio_manager_8h.html#a43f938ca6a048b535e79df160952e883", null ],
    [ "_ov_header_fseek_wrap", "dc/d84/spp___audio_manager_8h.html#a95f2bdb848e5df58eb39a50bfe91abff", null ]
];