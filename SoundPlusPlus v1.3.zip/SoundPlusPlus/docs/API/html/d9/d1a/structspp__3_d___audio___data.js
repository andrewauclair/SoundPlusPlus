var structspp__3_d___audio___data =
[
    [ "isLooping", "d9/d1a/structspp__3_d___audio___data.html#a32c04f0c57761ea5693b978984c99dee", null ],
    [ "position", "d9/d1a/structspp__3_d___audio___data.html#a4d2948fdcbf2723cdac9926e2e9d0027", null ],
    [ "velocity", "d9/d1a/structspp__3_d___audio___data.html#a27e4209abde00e6eaac88ba69dbf5820", null ],
    [ "volume", "d9/d1a/structspp__3_d___audio___data.html#a72de895580549d7476c81f8ae5c1cd89", null ]
];