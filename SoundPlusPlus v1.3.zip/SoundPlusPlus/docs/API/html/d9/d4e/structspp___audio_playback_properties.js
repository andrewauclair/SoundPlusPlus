var structspp___audio_playback_properties =
[
    [ "Looping", "d9/d4e/structspp___audio_playback_properties.html#a3ba15c1b1313e482b627f1746e1c8a00", null ],
    [ "MaximumVolume", "d9/d4e/structspp___audio_playback_properties.html#a5d6a6cf38561b75fe65afe68af43542f", null ],
    [ "MinimumVolume", "d9/d4e/structspp___audio_playback_properties.html#ac189c8e62d4c3fe87e87ad70543eeea6", null ],
    [ "Pitch", "d9/d4e/structspp___audio_playback_properties.html#ad21059c704d7ce549b39c9660a9d46f6", null ],
    [ "Volume", "d9/d4e/structspp___audio_playback_properties.html#a3f6d82baafb32140a76eb90f30362114", null ]
];