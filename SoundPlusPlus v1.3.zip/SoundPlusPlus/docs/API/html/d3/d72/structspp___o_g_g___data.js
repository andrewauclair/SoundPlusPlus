var structspp___o_g_g___data =
[
    [ "dataSize", "d3/d72/structspp___o_g_g___data.html#a27fc0bcf19c2e35ffdc3c8ee4f6e718b", null ],
    [ "endian", "d3/d72/structspp___o_g_g___data.html#adbf7b01c74af47c67b81b8031d8b9009", null ],
    [ "File", "d3/d72/structspp___o_g_g___data.html#aef1491420692fa2fb055f5e7e9964559", null ],
    [ "format", "d3/d72/structspp___o_g_g___data.html#a720f635874d1224c39d1a6131add1daf", null ],
    [ "freq", "d3/d72/structspp___o_g_g___data.html#aa77f18dce029b6711f541a21650c027b", null ],
    [ "oggFile", "d3/d72/structspp___o_g_g___data.html#ad37e360cba47bdb06a3f4edfaabc9f04", null ],
    [ "pInfo", "d3/d72/structspp___o_g_g___data.html#a0859ce92d5c512d46c5c49ca337b4fb5", null ]
];