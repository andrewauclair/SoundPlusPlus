var classspp___signal_processor =
[
    [ "spp_SignalProcessor", "d3/da9/classspp___signal_processor.html#a4ba18da945add5b4ddae0acbc267069b", null ],
    [ "~spp_SignalProcessor", "d3/da9/classspp___signal_processor.html#ab19f035bb8fcde57bc2b872e00ed7813", null ],
    [ "AddProcessingPlugIn", "d3/da9/classspp___signal_processor.html#a544b5f9cfc94d642ebf14a8a92dccf46", null ],
    [ "ProcessSamples", "d3/da9/classspp___signal_processor.html#a1fdb8b4f2922d7f72753adb3f98e9b66", null ],
    [ "RemoveAllProcessingPlugIns", "d3/da9/classspp___signal_processor.html#a5b5e767868b67775de285a996b21b441", null ],
    [ "RemoveProcessingPlugIn", "d3/da9/classspp___signal_processor.html#a8bfd8d5fddf9e0d1106931fde23448d8", null ],
    [ "SetAllPlugInStates", "d3/da9/classspp___signal_processor.html#a30a405610e351058d9a32874022fd4e6", null ],
    [ "SetPlugInState", "d3/da9/classspp___signal_processor.html#ab9ee282f3681d177e9f9721f7c25f6d3", null ]
];